import os
import numpy as np
import math
from PIL import Image, ImageEnhance
import cv2
import time
from skimage.metrics import structural_similarity
# from scipy.misc import imread
import numpy as np
start = time.perf_counter()


# 当中是你的程序

def psnr(img1, img2):
    mse = np.mean((img1 / 1. - img2 / 1.) ** 2)
    if mse < 1.0e-10:
        return 100 * 1.0
    return 10 * math.log10(255.0 * 255.0 / mse)

def ssim(img1,img2):
    img2 = np.resize(img2, (img1.shape[0], img1.shape[1], img1.shape[2]))
    ssim = structural_similarity(img1, img2, channel_axis=2)
    return ssim

def gssim(img1,img2):
    img2 = np.resize(img2, (img1.shape[0], img1.shape[1], img1.shape[2]))
    ssim = structural_similarity(img1, img2, channel_axis=2)

    #分别求X,Y方向的梯度
    img1_grad_X=cv2.Sobel(img1,-1,1,0,ksize=3)
    img1_grad_X_sum = np.sum(img1_grad_X)  # axis可以指定哪个轴上相加求和 横
    img1_grad_Y=cv2.Sobel(img1,-1,0,1,ksize=3)
    img1_grad_Y_sum = np.sum(img1_grad_Y)  # axis可以指定哪个轴上相加求和 纵
    img1_grad = abs(2*img1_grad_X_sum * img1_grad_Y_sum + 0.0005) / (img1_grad_X_sum**2 + img1_grad_Y_sum**2 + 0.005)

    img2_grad_X=cv2.Sobel(img2,-1,1,0,ksize=3)
    img2_grad_X_sum = np.sum(img2_grad_X)  # axis可以指定哪个轴上相加求和 横
    img2_grad_Y=cv2.Sobel(img2,-1,0,1,ksize=3)
    img2_grad_Y_sum = np.sum(img2_grad_Y)  # axis可以指定哪个轴上相加求和 纵
    img2_grad = abs(2*img2_grad_X_sum * img2_grad_Y_sum + 0.0005) / (img2_grad_X_sum**2 + img2_grad_Y_sum**2 + 0.0005)

    gssim_value = ssim * (img1_grad*img2_grad)
    return gssim_value

list_psnr = []
list_ssim = []
list_gssim = []
for i in range(0, 4):

    img_a = Image.open('/pytorch-ZSSR-master/test_data/3/0000.png')
    img_b = Image.open('/pytorch-ZSSR-master/test_data/3/03/0001.png')

    contrast_enhancer_a = ImageEnhance.Contrast(img_a)
    contrast_enhancer_b = ImageEnhance.Contrast(img_b)
    pil_enhanced_image_a = contrast_enhancer_a.enhance(2)
    pil_enhanced_image_b = contrast_enhancer_b.enhance(2)
    enhanced_image_a = np.asarray(pil_enhanced_image_a)
    enhanced_image_b = np.asarray(pil_enhanced_image_b)
    r1, g1, b1 = cv2.split(enhanced_image_a)
    r2, g2, b2 = cv2.split(enhanced_image_b)
    img_a = cv2.merge([b1, g1, r1])
    img_b = cv2.merge([b2, g2, r2])

    size = (256, 256)#The size of the smaller of the two images
    #两张图片中尺寸较小的那一个的尺寸值
    img_a = cv2.resize(img_a, dsize=size)
    img_b = cv2.resize(img_b, dsize=size)

    img_a = np.array(img_a)
    img_b = np.array(img_b)

    psnr_num = psnr(img_a, img_b)
    ssim_num = ssim(img_a, img_b)
    gssim_num = gssim(img_a, img_b)

    list_ssim.append(ssim_num)
    list_gssim.append(gssim_num)
    list_psnr.append(psnr_num)

print("平均PSNR:", np.mean(list_psnr))  # ,list_psnr)
print("平均SSIM:", np.mean(list_ssim))  # ,list_ssim)
print("平均GSSIM:", np.mean(list_gssim))  # ,list_gssim)

elapsed = (time.perf_counter() - start)
print("Time used:", elapsed)
