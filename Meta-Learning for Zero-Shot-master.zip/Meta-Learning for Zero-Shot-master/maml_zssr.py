import glob
import os
from utils import prepare_result_dir
import sys
import run_ZSSR_single_input
import configs
import ZSSR_maml
import random


def main(conf_name):
    if conf_name is None:
        conf = configs.Config()

    else:
        namespace = {'conf':None}
        conf = eval('configs.%s'%conf_name)

    res_dir = prepare_result_dir(conf)
    local_dir = os.path.dirname(__file__)

    files = [file_path for file_path in glob.glob('%s/*.png'%conf.input_path) if not file_path[-7:-4]=='_gt']


    # random.seed(100)


    for file_ind, input_file in enumerate(files):
        ground_truth_file = input_file[:-4] + '_gt.png'
        if not os.path.isfile(ground_truth_file):
            ground_truth_file = None
        

        kernel_files = ['%s_%d.mat;'%(input_file[:-4],ind) for ind in range(len(conf.scale_factors))]
        kernel_files_str = ''.join(kernel_files)
        for kernel_file in kernel_files:
            if not os.path.isfile(kernel_file[:-1]):
                kernel_files_str = None
                break
        
        ground_truth = ground_truth_file
        kernels = kernel_files_str

        conf = configs.Config()

        if conf_name is not None:
            exec('conf=configs.%s'%conf_name)
        
        conf.result_path = res_dir
        meta_files = []
        for _  in range(5):
            meta_files.append(files[random.randint(0,len(files)-1)])
        net = ZSSR_maml.ZSSR(input_file,conf,ground_truth,kernels,meta_files)
        net.run()


if __name__=='__main__':
    conf_str = sys.argv[1] if len(sys.argv) >  1 else None
    main(conf_str)