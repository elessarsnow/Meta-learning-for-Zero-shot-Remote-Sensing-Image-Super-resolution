# import tifffile as tif

# import glob


# paths = glob.glob('../img/airplane/*.tif')
# for path in paths:
#     img = tif.imread(path)
#     print(path.replace('tif','png').replace('img','imgs'))
#     tif.imwrite(path.replace('tif','png').replace('img','imgs'),img)



# 以tiff转png为例，其他格式同理，
# 代码中路径更改为自己图像存放路径即可
from PIL import Image
import os
#
# imagesDirectory= "../img/airplane"  # tiff图片所在文件夹路径
# distDirectory = os.path.dirname(imagesDirectory)
# distDirectory = os.path.join(distDirectory, "pngimage")# 要存放png格式的文件夹路径
# for imageName in os.listdir(imagesDirectory):
#     imagePath = os.path.join(imagesDirectory, imageName)
#     image = Image.open(imagePath)# 打开tiff图像
#     distImagePath = os.path.join(distDirectory, imageName[:-4]+'.png')# 更改图像后缀为.png，与原图像同名
#     image.save(distImagePath)# 保存png图像

imagesDirectory= "img\\river"  # tiff图片所在文件夹路径
distDirectory = os.path.dirname(imagesDirectory)
distDirectory = os.path.join(distDirectory, "pngimage")# 要存放png格式的文件夹路径
for imageName in os.listdir(imagesDirectory):
    imagePath = os.path.join(imagesDirectory, imageName)
    image = Image.open(imagePath)# 打开tiff图像
    distImagePath = os.path.join(distDirectory, imageName[:-4]+'.png')# 更改图像后缀为.png，与原图像同名
    image.save(distImagePath)# 保存png图像