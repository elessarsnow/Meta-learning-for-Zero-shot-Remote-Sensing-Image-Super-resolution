# 转换图片格式 并重命名
import PIL.Image
import os


# i=0


# class Solution:
def jpg_to_png(path: str, savepath: str):
    i = 0
    filelist = os.listdir(path)
    for file in filelist:
        img= PIL.Image.open(path + filelist[i])
        filename = os.path.splitext(file)[0]
        # im.save(savepath+filename+'.png') # or 'test.tif'
        img = img.convert("RGB")
        img.save(savepath + str(i).zfill(4) + '.png')  # or 'test.tif'
        i = i + 1
    return print("done")


if __name__ == '__main__':
    path = r"D:\pythonProject\pytorch-ZSSR-master\test_data\4\\"
    savepath = r"D:\pythonProject\pytorch-ZSSR-master\test_data\3\\"
    jpg_to_png(path, savepath)