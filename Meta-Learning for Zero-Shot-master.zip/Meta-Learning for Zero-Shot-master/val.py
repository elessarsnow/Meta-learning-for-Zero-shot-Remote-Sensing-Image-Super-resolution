from PIL import Image
import cv2
import glob
import math
import numpy as np
import torch
from torch.autograd import Variable
import pytorch_ssim

def psnr(img1, img2):
    img1 = np.float64(img1)
    img2 = np.float64(img2)
    mse = np.mean( (img1 - img2) ** 2 )
    if mse == 0:
        return 100
    PIXEL_MAX = 255.0
    return 20 * math.log10(PIXEL_MAX / math.sqrt(mse))



def ssim(img1,img2):
    img1 = torch.from_numpy(np.rollaxis(img1, 2)).float().unsqueeze(0)/255.0
    img2 = torch.from_numpy(np.rollaxis(img2, 2)).float().unsqueeze(0)/255.0   
    img1 = Variable( img1)    # torch.Size([256, 256, 3])
    img2 = Variable( img2)
    img1 = img1[:,:1,:,:]
    img2 = img2[:,:1,:,:]
    # print(img1.shape)

    ssim_value = pytorch_ssim.ssim(img1, img2)
    # ssims  = pytorch_ssim.SSIM(window_size=11)
    return ssim_value
#
def gssim(img1,img2):
    img1 = torch.from_numpy(np.rollaxis(img1, 2)).float().unsqueeze(0) / 255.0
    img2 = torch.from_numpy(np.rollaxis(img2, 2)).float().unsqueeze(0) / 255.0

    img_1 = Variable(img1)  # torch.Size([256, 256, 3])
    img_2 = Variable(img2)
    img_1 = img_1[:, :1, :, :]
    img_2 = img_2[:, :1, :, :]
    ssim_value = pytorch_ssim.ssim(img_1, img_2)

    #分别求X,Y方向的梯度
    img1_grad_X=cv2.Sobel(img1,cv2.CV_64F,1,0,ksize=3)
    img1_grad_X_sum = np.sum(img1_grad_X)  # axis可以指定哪个轴上相加求和 横
    img1_grad_Y=cv2.Sobel(img1,cv2.CV_64F,0,1,ksize=3)
    img1_grad_Y_sum = np.sum(img1_grad_Y)  # axis可以指定哪个轴上相加求和 纵
    img1_grad = abs(2*img1_grad_X_sum * img1_grad_Y_sum + 0.0005) / (img1_grad_X_sum**2 + img1_grad_Y_sum**2 + 0.0005)

    img2_grad_X=cv2.Sobel(img2,cv2.CV_64F,1,0,ksize=3)
    img2_grad_X_sum = np.sum(img2_grad_X)  # axis可以指定哪个轴上相加求和 横
    img2_grad_Y=cv2.Sobel(img2,cv2.CV_64F,0,1,ksize=3)
    img2_grad_Y_sum = np.sum(img2_grad_Y)  # axis可以指定哪个轴上相加求和 纵
    img2_grad = abs(2*img2_grad_X_sum * img2_grad_Y_sum + 0.0005) / (img2_grad_X_sum**2 + img2_grad_Y_sum**2 + 0.0005)

    gssim_value = ssim_value * (img1_grad,img2_grad)
    return gssim_value



paths_gt = glob.glob(r'results\\test_Jun_05_05_30_46\\*.png')
psnr_s = 0
ssim_s = 0
gssim_s = 0
for gt in paths_gt:
    # print(gt)
    name = gt.split(r'test_Jun_05_05_30_46')[-1].split('_')[0]
    #print(name,'img\\pngimage\\'+name+'.png')
    source_img = cv2.imread('img\\pngimage\\'+name+'.png')
    # print(source_img.shape)
    gt_img = cv2.imread(gt)
    h,w,_ = source_img.shape
    gt_img = cv2.resize(gt_img,(w,h))
    psnr_s += psnr(source_img,gt_img)
    ssim_s += ssim(source_img,gt_img)
    gssim_s += gssim(source_img,gt_img)
print(psnr_s/len(paths_gt),ssim_s/len(paths_gt),gssim_s/len(paths_gt))
